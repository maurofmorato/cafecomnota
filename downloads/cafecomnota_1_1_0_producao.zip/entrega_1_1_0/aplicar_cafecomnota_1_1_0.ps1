$ErrorActionPreference = 'Stop'

$deliveryRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $deliveryRoot
$sourceRoot = Join-Path $deliveryRoot 'src'
$outputDirectory = 'D:\temp\cafecomnota'
$backupRoot = Join-Path $outputDirectory (
    'backup_before_1_1_0_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
)

$files = @(
    'app/build.gradle.kts',
    'app/src/main/java/com/maurofmorato/cafecomnota/data/supabase/SupabaseCoffeeApi.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/components/CafeComponents.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/i18n/AppStrings.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/model/CoffeeUiModel.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/screens/CoffeeShareDialog.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/screens/HomeScreen.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/screens/RankingScreen.kt',
    'app/src/test/java/com/maurofmorato/cafecomnota/ui/model/CoffeeRankingTest.kt',
    'database/cafecomnota_1_1_0_ranking_custo_beneficio.sql'
)

$originallyExisting = @{}

Set-Location $projectRoot

if (-not (Test-Path -LiteralPath '.git')) {
    throw "O destino nao e o repositorio Cafe com nota: $projectRoot"
}

$buildFile = Join-Path $projectRoot 'app\build.gradle.kts'
$buildContent = [System.IO.File]::ReadAllText($buildFile)

if (
    $buildContent -notmatch 'versionCode\s*=\s*37' -or
    $buildContent -notmatch 'versionName\s*=\s*"1\.0\.37"'
) {
    throw 'Esta entrega exige a versao 1.0.37 como base.'
}

$modelFile = Join-Path $projectRoot (
    'app\src\main\java\com\maurofmorato\cafecomnota\ui\model\' +
    'CoffeeUiModel.kt'
)
$modelContent = [System.IO.File]::ReadAllText($modelFile)

if (
    $modelContent -notmatch 'totalValueReviews' -or
    $modelContent -notmatch 'bayesianValueRankingScore'
) {
    throw 'A base nao contem o ranking de custo-beneficio da versao 1.0.37.'
}

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

try {
    foreach ($relativePath in $files) {
        $source = Join-Path $sourceRoot $relativePath
        $destination = Join-Path $projectRoot $relativePath
        $backup = Join-Path $backupRoot $relativePath

        if (-not (Test-Path -LiteralPath $source)) {
            throw "Arquivo ausente na entrega: $relativePath"
        }

        $originallyExisting[$relativePath] = Test-Path -LiteralPath $destination

        if ($originallyExisting[$relativePath]) {
            New-Item -ItemType Directory `
                -Path (Split-Path -Parent $backup) `
                -Force |
                Out-Null

            Copy-Item -LiteralPath $destination -Destination $backup -Force
        }

        New-Item -ItemType Directory `
            -Path (Split-Path -Parent $destination) `
            -Force |
            Out-Null

        Copy-Item -LiteralPath $source -Destination $destination -Force
    }

    Write-Host "`n=== VALIDACAO DE FORMATACAO ===" -ForegroundColor Cyan

    git diff --check -- @files
    if ($LASTEXITCODE -ne 0) {
        throw 'A validacao Git de formatacao falhou.'
    }

    foreach ($relativePath in $files) {
        $destination = Join-Path $projectRoot $relativePath
        $lineNumber = 0

        foreach ($line in Get-Content -LiteralPath $destination) {
            $lineNumber++

            if ($line -match "[ `t]+$") {
                throw "Espaco no fim da linha: ${relativePath}:${lineNumber}"
            }
        }
    }

    $appliedBuildContent = [System.IO.File]::ReadAllText($buildFile)
    if (
        $appliedBuildContent -notmatch 'versionCode\s*=\s*110' -or
        $appliedBuildContent -notmatch 'versionName\s*=\s*"1\.1\.0"'
    ) {
        throw 'A versao 1.1.0 nao foi aplicada corretamente.'
    }

    Write-Host "`n=== TESTES UNITARIOS ===" -ForegroundColor Cyan
    & .\gradlew.bat testDebugUnitTest
    if ($LASTEXITCODE -ne 0) {
        throw 'Os testes unitarios falharam.'
    }

    Write-Host "`n=== COMPILACAO DEBUG ===" -ForegroundColor Cyan
    & .\gradlew.bat assembleDebug
    if ($LASTEXITCODE -ne 0) {
        throw 'A compilacao de depuracao falhou.'
    }

    Write-Host "`n=== GERACAO DO AAB ===" -ForegroundColor Cyan
    & .\gradlew.bat bundleRelease
    if ($LASTEXITCODE -ne 0) {
        throw 'A geracao do AAB falhou.'
    }

    $aabSource = Join-Path $projectRoot (
        'app\build\outputs\bundle\release\app-release.aab'
    )
    $aabDestination = Join-Path $outputDirectory (
        'cafecomnota-1.1.0-release.aab'
    )

    if (-not (Test-Path -LiteralPath $aabSource)) {
        throw "O AAB nao foi encontrado: $aabSource"
    }

    Copy-Item -LiteralPath $aabSource -Destination $aabDestination -Force

    $sqlPath = Join-Path $projectRoot (
        'database\cafecomnota_1_1_0_ranking_custo_beneficio.sql'
    )

    if (Get-Command Set-Clipboard -ErrorAction SilentlyContinue) {
        Get-Content -LiteralPath $sqlPath -Raw -Encoding UTF8 |
            Set-Clipboard
    }
}
catch {
    Write-Host "`nRevertendo os arquivos da entrega..." -ForegroundColor Yellow

    foreach ($relativePath in $files) {
        $destination = Join-Path $projectRoot $relativePath
        $backup = Join-Path $backupRoot $relativePath

        if ($originallyExisting[$relativePath]) {
            Copy-Item -LiteralPath $backup -Destination $destination -Force
        } elseif (Test-Path -LiteralPath $destination) {
            Remove-Item -LiteralPath $destination -Force
        }
    }

    Write-Host "Backup preservado em: $backupRoot" -ForegroundColor Yellow
    throw
}

Write-Host "`nCafe com nota 1.1.0 aplicada e compilada." -ForegroundColor Green
Write-Host "Nenhum emulador foi iniciado."
Write-Host "AAB para teste interno: $aabDestination"
Write-Host "Backup anterior: $backupRoot"

Write-Host "`n=== IMPORTANTE: BANCO AINDA NAO FOI ALTERADO ===" -ForegroundColor Yellow
Write-Host "O SQL foi copiado para a area de transferencia."
Write-Host "Execute-o antes de testar o ranking de custo-beneficio."
Write-Host "Essa migracao nao apaga nem modifica avaliacoes ou cafes."
Write-Host "SQL preparado: $sqlPath"

Write-Host "`n=== SHA-256 DO AAB ===" -ForegroundColor Cyan
Get-FileHash -LiteralPath $aabDestination -Algorithm SHA256

Write-Host "`n=== VERSAO ===" -ForegroundColor Cyan
Get-Content .\app\build.gradle.kts |
    Select-String 'versionCode|versionName'

Write-Host "`n=== ALTERACOES ===" -ForegroundColor Cyan
git diff --stat -- @files

Write-Host "`n=== STATUS ===" -ForegroundColor Cyan
git status --short
