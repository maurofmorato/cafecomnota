$ErrorActionPreference = 'Stop'

$deliveryRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $deliveryRoot
$sourceRoot = Join-Path $deliveryRoot 'src'
$expectedCommit = 'f3f9be0'

$files = @(
    'app/build.gradle.kts',
    'app/src/main/java/com/maurofmorato/cafecomnota/data/supabase/SupabaseCoffeeApi.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/data/supabase/SupabaseCoffeeImageLoader.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/model/CoffeeUiModel.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/screens/HomeScreen.kt',
    'app/src/test/java/com/maurofmorato/cafecomnota/ui/model/CoffeeRankingTest.kt'
)

$newFiles = @(
    'app/src/test/java/com/maurofmorato/cafecomnota/ui/model/CoffeeRankingTest.kt'
)

Set-Location $projectRoot

if (-not (Test-Path -LiteralPath '.git')) {
    throw "O destino nao e o repositorio Cafe com nota: $projectRoot"
}

$currentCommit = (git rev-parse --short HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or -not $currentCommit.StartsWith($expectedCommit)) {
    throw "Esta entrega exige o commit $expectedCommit. Commit atual: $currentCommit"
}

git diff --quiet
if ($LASTEXITCODE -ne 0) {
    throw 'Existem alteracoes em arquivos rastreados. Salve-as antes de aplicar esta entrega.'
}

git diff --cached --quiet
if ($LASTEXITCODE -ne 0) {
    throw 'Existem alteracoes preparadas para commit. Salve-as antes de aplicar esta entrega.'
}

try {
    foreach ($relativePath in $files) {
        $source = Join-Path $sourceRoot $relativePath
        $destination = Join-Path $projectRoot $relativePath

        if (-not (Test-Path -LiteralPath $source)) {
            throw "Arquivo ausente na entrega: $relativePath"
        }

        $destinationDirectory = Split-Path -Parent $destination
        New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }

    git diff --check -- @files
    if ($LASTEXITCODE -ne 0) {
        throw 'A validacao de formatacao falhou.'
    }

    & .\gradlew.bat testDebugUnitTest
    if ($LASTEXITCODE -ne 0) {
        throw 'Os testes unitarios falharam.'
    }

    & .\gradlew.bat assembleDebug
    if ($LASTEXITCODE -ne 0) {
        throw 'A compilacao de depuracao falhou.'
    }

    & .\gradlew.bat bundleRelease
    if ($LASTEXITCODE -ne 0) {
        throw 'A geracao do AAB de teste interno falhou.'
    }

    $aabSource = Join-Path $projectRoot 'app\build\outputs\bundle\release\app-release.aab'
    if (-not (Test-Path -LiteralPath $aabSource)) {
        throw "O Gradle terminou, mas o AAB nao foi encontrado: $aabSource"
    }

    $aabDirectory = 'D:\temp\cafecomnota'
    $aabDestination = Join-Path $aabDirectory 'cafecomnota-1.0.36-release.aab'
    New-Item -ItemType Directory -Path $aabDirectory -Force | Out-Null
    Copy-Item -LiteralPath $aabSource -Destination $aabDestination -Force
}
catch {
    Write-Host "`nRevertendo a entrega..." -ForegroundColor Yellow

    foreach ($relativePath in $files) {
        git ls-files --error-unmatch -- $relativePath 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            git restore --source=HEAD --worktree -- $relativePath
        }
    }

    foreach ($relativePath in $newFiles) {
        $target = Join-Path $projectRoot $relativePath
        if (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }

    throw
}

Write-Host "`nCafe com nota 1.0.36 aplicada, testada e compilada com sucesso." -ForegroundColor Green
Write-Host "Nenhum emulador foi iniciado."
Write-Host "AAB para teste interno: $aabDestination"

Write-Host "`n=== SHA-256 DO AAB ===" -ForegroundColor Cyan
Get-FileHash -LiteralPath $aabDestination -Algorithm SHA256

Write-Host "`n=== VERSAO ===" -ForegroundColor Cyan
Get-Content .\app\build.gradle.kts |
    Select-String 'versionCode|versionName'

Write-Host "`n=== ALTERACOES ===" -ForegroundColor Cyan
git diff --stat -- @files

Write-Host "`n=== STATUS ===" -ForegroundColor Cyan
git status --short
