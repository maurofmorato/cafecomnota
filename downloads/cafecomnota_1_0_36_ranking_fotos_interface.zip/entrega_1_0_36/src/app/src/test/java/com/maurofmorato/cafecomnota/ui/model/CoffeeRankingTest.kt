package com.maurofmorato.cafecomnota.ui.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoffeeRankingTest {
    @Test
    fun bayesianRankingValuesMoreReviewsWhenAveragesAreClose() {
        val oneReview = coffee(name = "Uma avaliação", rating = 4.5, reviews = 1)
        val fourReviews = coffee(name = "Quatro avaliações", rating = 4.4, reviews = 4)

        val oneReviewScore = bayesianRankingScore(oneReview, catalogAverage = 4.3)
        val fourReviewsScore = bayesianRankingScore(fourReviews, catalogAverage = 4.3)

        assertTrue(fourReviewsScore > oneReviewScore)
    }

    @Test
    fun topRatedUsesBayesianScoreButPreservesOriginalRating() {
        val coffees = listOf(
            coffee(name = "Uma avaliação", rating = 4.5, reviews = 1),
            coffee(name = "Quatro avaliações", rating = 4.4, reviews = 4),
            coffee(name = "Referência", rating = 4.3, reviews = 20)
        )

        val ranked = topRatedCoffees(coffees)

        assertEquals("Quatro avaliações", ranked.first().name)
        assertEquals(4.4, ranked.first().rating, 0.0)
    }

    private fun coffee(
        name: String,
        rating: Double,
        reviews: Int
    ) = CoffeeUiModel(
        id = name,
        name = name,
        brand = "Marca",
        type = "Moído",
        roast = "Média",
        rating = rating,
        totalReviews = reviews,
        priceKg = 50.0,
        wouldBuyAgainPercent = 0,
        description = "",
        tags = emptyList(),
        aroma = 0.0,
        flavor = 0.0,
        body = 0.0,
        acidity = 0.0,
        bitterness = 0.0,
        sweetness = 0.0,
        valueRating = 0.0
    )
}
