$ErrorActionPreference = 'Stop'

$deliveryRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $deliveryRoot
$sourceRoot = Join-Path $deliveryRoot 'src'
$expectedCommit = '3bb4e2a'

$files = @(
    'app/build.gradle.kts',
    'app/src/main/java/com/maurofmorato/cafecomnota/CafeComNotaApp.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/data/coffee/CoffeeStoredPhoto.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/data/coffee/SupabaseCoffeePhotoRepository.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/data/supabase/SupabaseCoffeeImageLoader.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/components/CafeComponents.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/components/CoffeePhotoManager.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/screens/CoffeeModerationDetailScreen.kt'
)

$newFiles = @(
    'app/src/main/java/com/maurofmorato/cafecomnota/data/coffee/CoffeeStoredPhoto.kt',
    'app/src/main/java/com/maurofmorato/cafecomnota/ui/components/CoffeePhotoManager.kt'
)

Set-Location $projectRoot

if (-not (Test-Path -LiteralPath '.git')) {
    throw "O destino não é o repositório Café com nota: $projectRoot"
}

$currentCommit = (git rev-parse --short HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or -not $currentCommit.StartsWith($expectedCommit)) {
    throw "Esta entrega exige o commit $expectedCommit. Commit atual: $currentCommit"
}

git diff --quiet
if ($LASTEXITCODE -ne 0) {
    throw 'Existem alterações em arquivos rastreados. Salve-as antes de aplicar esta entrega.'
}

git diff --cached --quiet
if ($LASTEXITCODE -ne 0) {
    throw 'Existem alterações preparadas para commit. Salve-as antes de aplicar esta entrega.'
}

try {
    foreach ($relativePath in $files) {
        $source = Join-Path $sourceRoot $relativePath
        $destination = Join-Path $projectRoot $relativePath

        if (-not (Test-Path -LiteralPath $source)) {
            throw "Arquivo ausente na entrega: $relativePath"
        }

        $destinationDirectory = Split-Path -Parent $destination
        New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }

    git diff --check -- @files
    if ($LASTEXITCODE -ne 0) {
        throw 'A validação de formatação falhou.'
    }

    & .\gradlew.bat assembleDebug
    if ($LASTEXITCODE -ne 0) {
        throw 'A compilação de depuração falhou.'
    }
}
catch {
    Write-Host "`nRevertendo a entrega..." -ForegroundColor Yellow

    foreach ($relativePath in $files) {
        git ls-files --error-unmatch -- $relativePath 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            git restore --source=HEAD --worktree -- $relativePath
        }
    }

    foreach ($relativePath in $newFiles) {
        $target = Join-Path $projectRoot $relativePath
        if (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }

    throw
}

Write-Host "`nCafe com nota 1.0.35 aplicada e compilada com sucesso." -ForegroundColor Green
Write-Host "Teste a gestão de fotos no celular antes de gerar o AAB."

Write-Host "`n=== VERSÃO ===" -ForegroundColor Cyan
Get-Content .\app\build.gradle.kts |
    Select-String 'versionCode|versionName'

Write-Host "`n=== ALTERAÇÕES ===" -ForegroundColor Cyan
git diff --stat -- @files

Write-Host "`n=== STATUS ===" -ForegroundColor Cyan
git status --short
